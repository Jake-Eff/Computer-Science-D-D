
public enum Nucleotide {
	A, G, T, C;
}
